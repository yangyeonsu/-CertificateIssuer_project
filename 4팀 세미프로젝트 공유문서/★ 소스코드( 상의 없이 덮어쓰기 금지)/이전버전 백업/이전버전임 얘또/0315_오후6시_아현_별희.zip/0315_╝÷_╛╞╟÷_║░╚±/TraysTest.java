public class TraysTest
{
	String s;
	int n;
	

	public TraysTest(String s, int n) 
	{
		this.s = s;
		this.n = n;
	}

	@Override
	public String toString()
	{
		return "Person [name=" + s + ", age=" + n + "]";
	}
}