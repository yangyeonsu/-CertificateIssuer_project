public class Play
{
	public static void main(String[] args)
	{
		Database db = new Database();
		db.input();
		Times t = new Times();
		t.calendar();
		FirstMenu fm = new FirstMenu();
		fm.option();
	}
}