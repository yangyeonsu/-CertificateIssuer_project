public class Play
{
	public static void main(String[] args) // ���� �޼ҵ� 
	{
		Database db = new Database();
		//db.input();
		Time t = new Time();
		//t.calendar();
		FirstMenu fm = new FirstMenu();
		fm.option();
	}
}