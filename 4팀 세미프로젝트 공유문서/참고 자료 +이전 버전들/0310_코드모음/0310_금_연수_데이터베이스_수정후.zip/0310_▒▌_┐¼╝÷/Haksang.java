public class Haksang(
{
	String name, hak, pw;
}
